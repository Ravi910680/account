
<?php
session_start();
$_SESSION['email']="sycista.social.server@gmail.com";
$_SESSION['id']=497889959;


$smtp_id=$_GET['smtp_id'];

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link rel="icon" href="https://res.cloudinary.com/heptera/image/upload/v1601995432/home_page/logo_heptera_1_jjjqnu.png" type="image/png" sizes="32x32">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<style>

.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;

border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;

}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}

.navbar{
  position: relative !important;
  border-bottom: 0px !important;
}

.add-new-site-main-con {
    width: 500px;
    margin: auto;
    text-align: center;
    margin-top: 40px;
    }





.ip-by-def-dsg{
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
}

.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



.ip-by-def-dsg-danje{
  background-color: #fff;
    outline: 0;
    border-color: #e20922;
    box-shadow: 0 0 0 3px #e2092245;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;

    }

    button.btn-theme-dsg:focus {
    box-shadow: 0 0 0 3px #4a154b4d;
    outline: 0;

}


.disp-inline-blc {
    display: inline-block;
    }


.side-nav-container {
    height: 92vh;
    width: 20%;
    display: inline-block;
    overflow: scroll;
    background: #4a154b;
    
  }
  .main-con-container {
    width: 79%;
    display: inline-block;
    height: 92vh;
    overflow: hidden;
    
  }

  div#main-content {
    height: 92vh;
    width: 100%;
overflow: hidden;
    
  }

.container-of-side-nav-lnk {
    padding-top: 40px;
  }

  .pers-link-side-nav {
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    transition: .2s;
    font-size: 15px;
  }

.pers-link-side-nav:hover{
  color: white;
}

.fal{
  padding-right: 20px;
}

.note-of-main-page {
    font-family: Roboto;
    font-style: normal;
    font-weight: initial;
    line-height: normal;
    font-size: 14px;
    color: #636363;
    text-align: center;
    padding: 40px;
  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
  }

  .own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
    background: transparent;

  }

  .own-dsg-of-dp-side a{

  }

  .own-dsg-of-dp-side a {
    padding: 5px 10px !important;
    color: rgb(207,195,207);
    font-size: 13px !important;
  }

  .own-dsg-of-dp-side a:focus{
background: #350c35;
    color: rgb(207,195,207);
  }

.dp-side-main-con {
    width: 100%;
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    font-size: 15px;

  }

  .dp-side-main-con:hover{
    color: white;

  }
.own-dsg-of-dp-side a:hover {
    background: #350c35;
    color: white;
  }

  .pad-left-20px-dp{
    padding-left: 20px;
  }

  .add-crt-dp-btn{
    float: right;
    font-size: 20px;
    padding: 0px 10px;
    color: white;
  }

  .fa-hashtag {
    padding-right: 7px;
    margin-right: 0px !important;
}










button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}



.lbl-for-acc-page {
    font-weight: 500;
    font-size: 14px;
    color: #3D3D3D;
    text-align: left;
    margin-bottom: 8px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    float: left;

    }

.add-new-site-main-con {
    width: 49%;
    margin: auto;
    text-align: center;
    display: inline-block;
    padding: 40px;
    overflow: scroll;
    height: 92vh;
  }



.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: #1264a3;
    font-weight: bolder;
  }
  .font-sz-fet-txt {
    letter-spacing: 0px;
    font-size: 16px;
  }
  .txt-para-dt {
    line-height: 1.5;
    
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;
    font-size: 15px;
  }

  .fet-data-con-main {
    width: 70%;
    margin: auto;
  }



  .add-new-site-main-con::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.add-new-site-main-con {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}




a.hrf-sml-lnk {
    font-size: 13px;
    color: rebeccapurple;
  }

i.ico-of-sede-sub-dp {
    margin-right: 0px !important;
    padding-right: 15px;
  }

  .cls-to-smtp-act {
    padding: 20px;
    text-align: right;
  }
  .cont-of-all-smtp-dt {
    width: 100%;
    display: inline-flex;
    margin-top: 5vh;
  }

  .btn_of_act {
    background: #540a47;
    font-size: 13px;
    border-radius: 5px;
    color: white;
    padding: 5px 15px;
    border: none;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-right: 20px;
  }
  .div-of-con-smtp {
   max-height: 500px;

    width: 40%;
    margin: auto;
    border-radius: 20px;
    box-shadow: rgb(99 99 99 / 20%) 0px 2px 8px 0px;
  }
  .head-of-smtp-def-data {
    padding: 2vh;
    font-weight: 600;
    font-size: 1.5vh;
    box-shadow: rgb(0 0 0 / 10%) 0px 4px 6px -1px, rgb(0 0 0 / 6%) 0px 2px 4px -1px;
    border-radius: 20px;
  }

  .send-det-of-dt {
    display: inline-flex;
    width: 100%;
    padding: 10px;
    border-bottom: 1px solid #f2f2f2;
    font-size: 13px;
  }

  .dsc-wdt {
    width: 33.333%;

  }

span.bdg-of-smtp {
    font-size: 10px;
    background: #145fef;
    color: white;
    padding: 4px 22px;
    border-radius: 10px;
  }

  .dsc-wdt.flg-of-send-det {
    text-align: right;
    padding-right: 20px;
  }

  .dropdown-toggle::after{
    display: none;
  }

  button:hover{
    cursor: pointer;
  }

  .txt-not-fd {
    padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
    font-size: 10px;
    max-width: 50%;

  }





.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}

label {
    color: black;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    }

    .two-flx-ip {
    display: inline-flex;
    width: 100%;
  }

  .ip-fld-sing {
    margin: auto;
    width: 100%;
  }

  .ip-by-def-dsg {
    width: 90%;
    padding: 0px 20px;
    height: 40px;
  }

  p.con-of-txt-data {
    font-size: 11px;
    width: 50%;
    margin: auto;
    text-align: center;
    margin-top: 30px;
    font-weight: 500;
  }

  .cont-of-res-api-tok {
    border: 1px solid #a59f9f !important;
    border-radius: 5px;
    color: #777373;
    width: 70%;
    margin: auto;
    margin-top: 20px;
  }
  .hold-token-ip {
    height: 40px;
    border: none;
    border-radius: 5px;
    width: 90%;
    padding: 10px;
  }

  .copy-clip-tok.cls-cop-handl {
    font-size: 20px;
    display: inline-block;
    width: 10%;
  }
  #not-fd-smt-cred{
    display: none;
  }

  .ldr-con {
    text-align: center;
    padding: 30px;
  }




button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}


</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <?php require("../../confige/header/header.php");?>


<div id="main-content">


    <?php require("../../confige/side-nav.php");?>


   <div class="main-con-container" id="add-site-main-con">


    <div class="cls-to-smtp-act">

    
<button id="del_smtp_serv" class="btn_of_act" data-modal-trigger='modal-del-smtp' style="
    background: white;
    ">
    <img src="https://res.cloudinary.com/heptera/image/upload/v1622783497/account/delete_forever_black_24dp_lu2vcp.svg" style="
    height: 18px;
"></button>

<button id="show_smtp_cred" data-modal-trigger="modal-send-api-data"  class="btn_of_act" style="
    ">
    <img src="https://res.cloudinary.com/heptera/image/upload/v1622782408/account/visibility_white_24dp_rbvosw.svg" style="
    padding-right: 10px;
    height: 18px;
">
Show Credentials
  </button>


<div class="dropdown" style="
">
  <button id="btn_chg_add_txt" style="
    background: #130d42;
    " class="btn_of_act dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    
All List<img src="https://res.cloudinary.com/heptera/image/upload/v1622783116/account/arrow_drop_down_white_18dp_f2sjn3.svg" style="
    padding-left: 10px;
">
  </button>
  <div class="dropdown-menu" id="list_of_all_smtp"  aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 30px, 0px);"><a class="dropdown-item hrf_of_sel_opt chg_chrt_data" href="#" data_id="">All List</a><a class="dropdown-item hrf_of_sel_opt chg_chrt_data" href="#" data_id="147860134^bmV3LWxpc3Q=">new-list</a><a class="dropdown-item hrf_of_sel_opt chg_chrt_data" href="#" data_id="147860134^bmV3X2xpc3Rfc2VuZF90ZXN0">new_list_send_test</a></div>
</div>
    

</div>

<div class="cont-of-all-smtp-dt">
    
        <div class="div-of-con-smtp">

    <div class="head-of-smtp-def-data">
    API Sending From Server
    </div>

    <div class="con-of-smtp-serv" id="con-of-api-send-by-serv">


<div class="ldr-con">

<div class="cp-spinner cp-round" style="
                                        "></div></div>
</div>

</div>
        
        <div class="div-of-con-smtp">

    <div class="head-of-smtp-def-data">
    Campign Sheduled By SMTP Server
    </div><div class="con-of-smtp-serv" id="con-of-camp-send-by-serv">
    
    <div class="ldr-con">

<div class="cp-spinner cp-round" style="
                                        "></div></div>

</div>

</div>
    
    </div>        














    </div>






    </div>










<div class="modal-2" data-modal="modal-del-smtp" id="modal-del-smtp">



<article class="content-wrapper" style="
    width: 30%;
">
<button type="button" class="close-2 close">
</button>
<div class="head-line-of-mdl" style="
    text-align: center;
">
<h4>Are You Sure to Delete This Campign Permanently. </h4>
</div>
<div class="content" style="text-align: center;font-size: 10px;">
<p style="
    font-size: 12px;
    font-weight: 500;
">Once Delete this campign We Not Able To Send And seduled any post or Email.please, review...</p>
</div>
<div class="btn-con-del-camp" style="
    width: 100%;
">
<button class="btn-theme-dsg del_email_camp" id="del_smtp_serv_fin" style="">Yes,Delete Campign</button>
</div>
</article>
</div>












<div class="modal-2 " data-modal="modal-send-api-data" id="mdl-send-api-data">
<article class="content-wrapper">
<button class="close"></button>
<header class="modal-2-header">
<h3>SMTP Credential</h3>
</header>
<div class="not-fd-data" id="not-fd-smt-cred"><img src="https://res.cloudinary.com/heptera/image/upload/v1622873494/account/undraw_Throw_away_re_x60k_svorji.svg" style="padding:20px;" height="100"><div class="txt-not-fd">Selcected SMTP server deleted by your permission so auftera not does not exist SMTP server Data.</div><button class="bottom-btn" data-modal-trigger="src_img_modal" id="ip-img-src-api" style="background: #94918d;border: none;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;color: black;font-size: 13px;font-weight: 600;float: none;">Add New Server</button></div>


<div class="con-of-cred-data">

    <div class="two-flx-ip">
    
        

<div class="ip-fld-sing"><label>Host</label>
  <input class="ip-by-def-dsg form-control on_chg_fld" id="host_fld_cred" aria-describedby="emailHelp" placeholder="host" style="
    margin: 0px;
"></div><div class="ip-fld-sing"><label>User Name</label>
<input class="ip-by-def-dsg form-control on_chg_fld" id="user_name_fld_cred" aria-describedby="emailHelp" placeholder="host" style="
    margin: 0px;
"></div>
        
    </div>

<div class="two-flx-ip" style="
    margin-top: 20px;
">
    
        

<div class="ip-fld-sing"><label>Password</label>
  <input class="ip-by-def-dsg form-control on_chg_fld" id="password_fld_cred" aria-describedby="emailHelp" placeholder="host" style="
    margin: 0px;
"></div><div class="ip-fld-sing"><label>port</label>
<input class="ip-by-def-dsg form-control on_chg_fld" id="port_fld_cred" aria-describedby="emailHelp" placeholder="host" style="
    margin: 0px;
"></div>
        
    </div>


</div>


<div class="con-of-api-use-con">

<p class="con-of-txt-data">Copy Below Code And use this code to At APY request Time <a href="">use custome SMTP server For API sending</a></p>

<div class="cont-of-res-api-tok"><input class="hold-token-ip" readonly="readonly" value="" id="smtp_id_fld_cred"><div class="copy-clip-tok cls-cop-handl" cop-id="1"><i class="fal fa-copy" aria-hidden="true"></i></div></div>

</div>

</article>
</div>


<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  
  
</body>



</html>

<script type="text/javascript">



smtp_server_data=[];

comb_arr=[];

smtp_id_pres="<?php echo $smtp_id;?>";

function get_camp_name(name){




return name.split("^")[1];

}

function get_smtp_name(smtp_id){

  
  

if(smtp_id==null){

return "Still Not";

}else{

if(smtp_id.length>=10){



  for (var i = 0; i < smtp_server_data.length; i++) {
    if(smtp_server_data[i]['smtp_id']==smtp_id){

      return smtp_server_data[i]['smtp_name'];
    }
  };

  return "deleted";
}else{
  return "sycista";
}
  
}
}

function get_str_of_status(flg,stat_tp){

if(stat_tp=="api"){

return '<img src="https://res.cloudinary.com/heptera/image/upload/v1619245988/done_all_black_24dp_dyha1n.svg" style=" height: 14px; ">';

}else{

if(flg>='1'){

return '<img src="https://res.cloudinary.com/heptera/image/upload/v1618934875/campign/edit_black_24dp_fhwu0s.svg" style=" height: 14px; ">';

}else{

return '<img src="https://res.cloudinary.com/heptera/image/upload/v1619245988/done_all_black_24dp_dyha1n.svg" style=" height: 14px; ">';

}

}

}

function append_str_of_smtp_det(api_str,camp_str){


if(api_str.length==0){

api_str='<div class="not-fd-data"><img src="https://res.cloudinary.com/heptera/image/upload/v1622821285/account/undraw_Accept_request_re_d81h_zf0qze.svg" style="padding:20px;" height="100"><div class="txt-not-fd">There is no data of send email from auftera api throught a any SMTP server.</div><button class="bottom-btn" data-modal-trigger="src_img_modal" id="ip-img-src-api" style="background: #94918d;border: none;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;color: black;font-size: 13px;font-weight: 600;float: none;">Read About API</button></div>';

}

if(camp_str.length==0){

camp_str='<div class="not-fd-data"><img src="https://res.cloudinary.com/heptera/image/upload/v1622821943/account/undraw_camping_noc8_1_mtu00o.svg" style="padding:20px;" height="100"><div class="txt-not-fd">Still you can not create campign or select SMTP server for campign.</div><button class="bottom-btn" style="background: #94918d;border: none;box-shadow: rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px;color: black;font-size: 13px;font-weight: 600;float: none;">Create Campign</button></div>';


}


$("#con-of-api-send-by-serv").html(api_str);
$("#con-of-camp-send-by-serv").html(camp_str);
  
}


function init_all_str_of_smtp(arr_of_data,smtp_id){

str_of_app_api="";
str_of_camp="";

console.log(arr_of_data);

for (var i = 0; i < arr_of_data.length; i++) {




if(smtp_id=="all" || smtp_id==arr_of_data[i]['smtp_id']){
  

  camp_name=get_camp_name(arr_of_data[i]['name']);
  smtp_name=get_smtp_name(arr_of_data[i]['smtp_id']);

if(arr_of_data[i]["name"]=="1^API"){



  str_of_stat=get_str_of_status(arr_of_data[i]['flg_camp_send'],'api');

  str_of_app_api+='<div class="send-det-of-dt"> <div class="dsc-wdt send-tp-fun"><span class="bdg-of-smtp">'+camp_name+'</span></div> <div class="dsc-wdt smtp-serv-name">'+smtp_name+'</div> <div class="dsc-wdt flg-of-send-det">'+str_of_stat+'</div> </div>';
}else{

 

  str_of_stat=get_str_of_status(arr_of_data[i]['flg_camp_send'],'camp');

str_of_camp+='<div class="send-det-of-dt"> <div class="dsc-wdt send-tp-fun"><span class="bdg-of-smtp">'+camp_name+'</span></div> <div class="dsc-wdt smtp-serv-name">'+smtp_name+'</div> <div class="dsc-wdt flg-of-send-det com-for-lnk" data-for-serv="1" data-path-ses="campign/" data-target-link="https://campign.auftera.com/campigns/?camp_id='+arr_of_data[i]['name']+'" >'+str_of_stat+'</div> </div>';


}


}

};


append_str_of_smtp_det(str_of_app_api,str_of_camp);



}



function get_data_of_smtp_send(){



$.ajax({
                url : "./ajaxfile/sel_smtp_serve.php",
                type: "GET"
                
        }).done(function(response){ 

    response=JSON.parse(response);

   

comb_arr=response['auftera'].concat(response['custom']);




init_all_str_of_smtp(comb_arr,smtp_id_pres);

        });


}

function init_drp_dwn_set(){

  str_app="";

for (var i = 0; i < smtp_server_data.length; i++) {
  

  str_app+='<a class="dropdown-item hrf_of_sel_opt chg_smtp_data" href="#" data_id="'+smtp_server_data[i]['smtp_id']+'">'+smtp_server_data[i]['smtp_name']+'</a>';
};

$("#list_of_all_smtp").html(str_app);

}

$(document).on('click','.chg_smtp_data',function(){

smtp_id_pres=$(this).attr('data_id');

init_all_str_of_smtp(comb_arr,smtp_id_pres);



})

function init_smtp_cred_mdl(arr_data){

  console.log(arr_data);

  for (const [key, value] of Object.entries(arr_data)) {

    selector="#"+key+"_fld_cred";
  $(selector).val(value);

  $(selector).prop('readonly', true);
}
}


$(document).on('click',"#show_smtp_cred",function(){


modalEvent(this);


  for (var i = 0; i < smtp_server_data.length; i++) {
    if(smtp_server_data[i]['smtp_id']==smtp_id_pres){


console.log("ravi");
init_smtp_cred_mdl(smtp_server_data[i]);

$(".con-of-cred-data").css('display',"block");
$(".con-of-api-use-con").css('display','block');
$("#not-fd-smt-cred").css('display','none');


return 0;
      
    }
  };



$(".con-of-cred-data").css('display',"none");
$(".con-of-api-use-con").css('display','none');
$("#not-fd-smt-cred").css('display','block');




})




$(document).ready(function(){





$.ajax({
                url : "../../ajaxfile-pages/get_all_smtp.php",
                type: "GET"
                
        }).done(function(response){ 

    response=JSON.parse(response);

   
smtp_server_data=response;

console.log(smtp_server_data);

get_data_of_smtp_send();

init_drp_dwn_set();

        });



})



function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
}



function copyToClipboard(id) {
  var copyText = document.getElementById(id);
  console.log(copyText);
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  
 
}



$(document).on("click",".cls-cop-handl",function(){

copyToClipboard("smtp_id_fld_cred");


});



$(document).on('click','#del_smtp_serv',function(){

modalEvent(this);


})

load_btn_txt="";

function app_loader_btn(selector){

load_btn_txt=$(selector).html();
$(selector).html('<div class="cp-spinner cp-round"></div>');
$(selector).css("disabled",true);

}

function app_text_btn(selector){

  $(selector).html(load_btn_txt);
}

$(document).on('click',"#del_smtp_serv_fin",function(){

app_loader_btn("#del_smtp_serv_fin");

$.ajax({
                url : "./ajaxfile/del_smtp_id.php",
                type: "GET",
                data:{smtp_id:smtp_id_pres}
                
        }).done(function(response){ 

    console.log(response);

    if(response==1){

window.location="../add_smtp/";

    }else{

app_text_btn("#del_smtp_serv_fin");
    }

        });

})

</script>


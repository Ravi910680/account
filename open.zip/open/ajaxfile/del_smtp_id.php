<?php

require("../../../confige/smtp_database.php");


$smtp_id=$_GET['smtp_id'];

$del_query="delete from smtp_server_data where smtp_id='".$smtp_id."'";

if ($conn_smtp->query($del_query) === TRUE) {
  echo 1;
} else {
  echo 0;
}


?>
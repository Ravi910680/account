<?php

session_start();

$id=$_SESSION['id'];


require("../../../confige/api_tbl.php");


$servername = "campign.chmwcgvoxwwi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="camp_email_db";




$camp_name_conn = mysqli_connect($servername, $username, $password,$db);


$res_arr=array("auftera"=>array(),"custom"=>array());


function get_api_send_tbl_name($conn,$id){

$sel_query="select * from `api-key` where usr_id='".$id."' and type='2'";


$result = $conn->query($sel_query);



if($result->num_rows>0){
$row = $result->fetch_assoc();

return $row['token'];

}

return 0;

}


function get_mail_camp($conn,$id){



$sel_query='select * from camp_name_tbl where id="'.$id.'"';


$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
    
$camp_id=$row['camp_contact_id'];

$sel_query="select smtp_id from camp_content_tbl where camp_id='".$camp_id."'";

$result2 = $conn->query($sel_query);

$row2 = $result2->fetch_assoc();

$loc_arr=array();

$loc_arr['name']=$row['camp_name'];
$loc_arr['smtp_id']=$row2['smtp_id'];
$loc_arr['flg_camp_send']=$row['flg_send'];


if($row2['smtp_id']<40){
array_push($GLOBALS['res_arr']['auftera'], $loc_arr);

}else{
array_push($GLOBALS['res_arr']['custom'], $loc_arr);

}


  }
} else {
 
}


return $loc_arr;


}

function get_api_send_tbl_report($conn,$api_tbl){


$loc_arr=array();

$sel_query="select count(con_id),smtp_id from ".$api_tbl." group by smtp_id";

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {

$loc_arr['name']="1^API";
$loc_arr['smtp_id']=$row['smtp_id'];
$loc_arr['flg_camp_send']=0;



if($row['smtp_id']<40){
array_push($GLOBALS['res_arr']['auftera'], $loc_arr);

}else{
array_push($GLOBALS['res_arr']['custom'], $loc_arr);

}


  }

}

}

get_mail_camp($camp_name_conn,$id);


$api_send_tbl_name=get_api_send_tbl_name($heptera_api_conn,$id);

if($api_send_tbl_name!==0){






get_api_send_tbl_report($hepter_api_send_tbl,$api_send_tbl_name);


}


print_r(json_encode($res_arr));

?>
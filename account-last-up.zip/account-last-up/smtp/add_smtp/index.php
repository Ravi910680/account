
<?php
session_start();
$mail=$_SESSION['email'];

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link rel="icon" href="https://res.cloudinary.com/heptera/image/upload/v1601995432/home_page/logo_heptera_1_jjjqnu.png" type="image/png" sizes="32x32">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="../../design/loader.css">

<style>

.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}

.navbar{
  position: relative !important;
  border-bottom: 0px !important;
}

div#main-content {
    height: 92vh;
}
.add-new-site-main-con {
    width: 500px;
    margin: auto;
    text-align: center;
    margin-top: 40px;
    }





.ip-by-def-dsg{
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;
}

.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



.ip-by-def-dsg-danje{
  background-color: #fff;
    outline: 0;
    border-color: #e20922;
    box-shadow: 0 0 0 3px #e2092245;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;

    }

    button.btn-theme-dsg:focus {
    box-shadow: 0 0 0 3px #4a154b4d;
    outline: 0;

}


.disp-inline-blc {
    display: inline-block;
    }


.side-nav-container {
    height: 92vh;
    width: 20%;
    display: inline-block;
    overflow: scroll;
    background: #4a154b;
    
  }
  .main-con-container {
    width: 79%;
    display: inline-block;
    height: 92vh;
    overflow: hidden;
    
  }

  div#main-content {
    height: 92vh;
    width: 100%;

    
  }

.container-of-side-nav-lnk {
    padding-top: 40px;
  }

  .pers-link-side-nav {
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    transition: .2s;
    font-size: 15px;
  }

.pers-link-side-nav:hover{
  color: white;
}

.fal{
  padding-right: 20px;
}

.note-of-main-page {
    font-family: Roboto;
    font-style: normal;
    font-weight: initial;
    line-height: normal;
    font-size: 14px;
    color: #636363;
    text-align: center;
    padding: 40px;
  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
  }

  .own-dsg-of-dp-side {
    border-radius: 10px !important;
    position: relative !important;
    transform: unset !important;
    width: 100%;
    background: transparent;

  }

  .own-dsg-of-dp-side a{

  }

  .own-dsg-of-dp-side a {
    padding: 5px 10px !important;
    color: rgb(207,195,207);
    font-size: 13px !important;
  }

  .own-dsg-of-dp-side a:focus{
background: #350c35;
    color: rgb(207,195,207);
  }

.dp-side-main-con {
    width: 100%;
    padding: 10px 20px;
    color: rgb(207,195,207);
    cursor: pointer;
    font-size: 15px;

  }

  .dp-side-main-con:hover{
    color: white;

  }
.own-dsg-of-dp-side a:hover {
    background: #350c35;
    color: white;
  }

  .pad-left-20px-dp{
    padding-left: 20px;
  }

  .add-crt-dp-btn{
    float: right;
    font-size: 20px;
    padding: 0px 10px;
    color: white;
  }

  .fa-hashtag {
    padding-right: 7px;
    margin-right: 0px !important;
}










button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}



.lbl-for-acc-page {
    font-weight: 500;
    font-size: 14px;
    color: #3D3D3D;
    text-align: left;
    margin-bottom: 8px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    float: left;

    }

.add-new-site-main-con {
    width: 49%;
    margin: auto;
    text-align: center;
    display: inline-block;
    padding: 40px;
    overflow: scroll;
    height: 92vh;
  }



.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: #1264a3;
    font-weight: bolder;
  }
  .font-sz-fet-txt {
    letter-spacing: 0px;
    font-size: 16px;
  }
  .txt-para-dt {
    line-height: 1.5;
    
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;
    font-size: 15px;
  }

  .fet-data-con-main {
    width: 70%;
    margin: auto;
  }



  .add-new-site-main-con::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.add-new-site-main-con {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}





a.hrf-sml-lnk {
    font-size: 13px;
    color: rebeccapurple;
  }


i.ico-of-sede-sub-dp {
    margin-right: 0px !important;
    padding-right: 15px;

  }

</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <?php require("../../confige/header/header.php");?>


<div id="main-loader-containre">


    <?php require("../../confige/side-nav.php");?>


    <div class="main-con-container" id='add-site-main-con'>


        








<div class="add-new-site-main-con">


  <div class="fet-data-con-main">
    <div class="fet-ico">
    <i class="fal fa-plus-circle" style='padding-right:0px;'></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" class='hrf-sml-lnk' data-clog-click="" data-clog-ui-element="link_document_sharing">Add Server Configuration</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Add server configuration in Sycista Account console with accurate credential.</div>
   


</div>

<div class="fet-data-con-main" style="
    margin-top: 50px;
    margin-bottom: 50px;
">
    <div class="fet-ico">
   <i class="fal fa-badge-check" style='padding-right:0px;'></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" class='hrf-sml-lnk' data-clog-click="" data-clog-ui-element="link_document_sharing">Verify Account</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Verify mail only send in your email account for only test not any response requied.</div>
   


</div>


<div class="fet-data-con-main">
    <div class="fet-ico">
    <i class="fal fa-paper-plane" style='padding-right:0px;'></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" class='hrf-sml-lnk' data-clog-click="" data-clog-ui-element="link_document_sharing">Use With API</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">this Smtp server will be used with our API System To send through This Smtp.</div>
   


</div>


</div>

<div class="add-new-site-main-con">
    
    <img src="https://res.cloudinary.com/heptera/image/upload/v1601567349/account/undraw_server_cluster_jwwq_hnlkrv.svg" style="
    width: 200px;
">
        

<div class="note-of-main-page">

Connect Your Site with sycista and get wide range of amazing feature like auto update sending image crawling.

</div>

        <div class="form-group">
          <label class="lbl-for-acc-page" for="exampleInputEmail1" style="
">Host</label>
    
    <input class="ip-by-def-dsg form-control on_chg_fld" id="host_fld" aria-describedby="emailHelp" placeholder="host">
    
  </div>
  <div class="form-group">
          <label class="lbl-for-acc-page" for="exampleInputEmail1" style="
">Username</label>
    
    <input class="ip-by-def-dsg form-control on_chg_fld" id="user_fld" aria-describedby="emailHelp" placeholder="username">
    
  </div>
  <div class="form-group">
          <label class="lbl-for-acc-page" for="exampleInputEmail1" style="
">Password</label>
    
    <input class="ip-by-def-dsg form-control on_chg_fld" id="pass_fld" aria-describedby="emailHelp" placeholder="password">
    
  </div>
  <div class="form-group">
          <label class="lbl-for-acc-page" for="exampleInputEmail1" style="
">Port</label>
    
    <input class="ip-by-def-dsg form-control on_chg_fld" id="port_fld" type='number' aria-describedby="emailHelp" placeholder="port">
    
  </div>


  <button class="btn-theme-dsg" id="btn-smtp-serve">Validate Server</button>

    
    </div>






    </div>






    </div>






  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
   <script type="text/javascript" src='https://account.sycista.com/account/js-file/init_side_nav_data_8.js'></script>
 <script type="text/javascript" src="https://account.sycista.com/account/confige/fun_for_red_lnk_3.js"></script> 
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">
</script>



</html>

<script type="text/javascript">

smtp_obj={};


$(document).on('change','.on_chg_fld',function(){



 $('.on_chg_fld').map(function() {
   

 smtp_obj[$(this).attr('id')]=$(this).val();




});


 console.log(smtp_obj);



});




$(document).on("click","#btn-smtp-serve",function(){


sub_smtp_server();

})





function sub_smtp_server(){

append_loader_of_btn("#btn-smtp-serve");

req_data=JSON.stringify(smtp_obj);


  $.ajax({
                url : "./ajaxfile/validate_server.php",
                type: "POST",
                data : {data:req_data}
        }).done(function(response){ 

if(response==1){

window.location.href="../validate/";


}

        });


}



function append_loader_of_btn(id){

$(id).html('<div class="cp-spinner cp-round"></div>');

$(id).prop('disabled', true);

}


</script>


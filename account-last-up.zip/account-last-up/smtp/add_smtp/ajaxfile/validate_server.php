<?php
session_start();
$req_data=$_POST;





$_SESSION['smtp-server']=json_decode($req_data['data']);





echo 1;


?>
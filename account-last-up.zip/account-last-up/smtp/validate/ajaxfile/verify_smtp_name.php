<?php
session_start();

require("../../../confige/smtp_database.php");

function get_random_id($digits){


return rand(pow(10, $digits-1), pow(10, $digits)-1);

}

$id=$_SESSION['id'];

$req_data=$_POST;

$smtp_name=$req_data['smtp_name'];

$smtp_host=$_SESSION['smtp-server']->host_fld;
$user_name=$_SESSION['smtp-server']->user_fld;
$password=$_SESSION['smtp-server']->pass_fld;
$port=$_SESSION['smtp-server']->port_fld;



$date= date('Y-m-d H:i:s');

$smtp_id=get_random_id(10);



$isrt_smtp_data="insert into smtp_server_data (id,smtp_id,smtp_name,host,user_name,password,port,date) value ('$id','$smtp_id','$smtp_name','$smtp_host','$user_name','$password','$port','$date')";


if ($conn_smtp->query($isrt_smtp_data) === TRUE) {
  echo 1;
} else {
  echo $conn_smtp->error;
}




?>

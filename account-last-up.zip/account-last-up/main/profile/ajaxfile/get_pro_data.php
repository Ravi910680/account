<?php
session_start();

$id=$_SESSION['id'];

require("../../../confige/account_database.php");

$res_array=array();

$sel_data="select * from profile_data where id='$id'";


$result = $conn_account->query($sel_data);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
$res_array=$row;

  }
} else {
  echo "0 results";
}

print_r(json_encode($res_array));

?>

<?php
session_start();

$id=$_SESSION['id'];

require("../../../confige/account_database.php");



$req_data=$_POST;

$fr_name=$req_data['fr_name'];
$ls_name=$req_data['ls_name'];
$country=$req_data['country'];
$phone=$req_data['phone'];
$addr=$req_data['addr'];



$up_query_account="update profile_data set fr_name='$fr_name',ls_name='$ls_name',country='$country',phone='$phone',addr='$addr' where id='$id'";




if ($conn_account->query($up_query_account) === TRUE) {
  echo 1;
} else {
  echo 0;
}


?>


$(document).ready(function(){


  set_all_site_data();



})


function set_all_site_data(){

  $.ajax({
                url : "https://account.sycista.com/account/ajaxfile-pages/get_all_site.php",
                type: "GET"
                
        }).done(function(response){ 
str_app_all_site="";

dec_data=JSON.parse(response);
$("#site_cnt_dt").html(dec_data.length);
for (var i = 0; i < dec_data.length; i++) {
  str_app_all_site+=crt_str_of_res_data('sites',dec_data[i]['url'],dec_data[i]['url_id'],dec_data[i]['status']);
};


$("#all-sites-conn").html(str_app_all_site);

set_all_smtp_data();

        });
}



function set_all_smtp_data(){




$.ajax({
                url : "https://account.sycista.com/account/ajaxfile-pages/get_all_smtp.php",
                type: "GET"
                
        }).done(function(response){ 
str_app_all_site="";

dec_data=JSON.parse(response);
$("#smtp_cnt_dt").html(dec_data.length);
for (var i = 0; i < dec_data.length; i++) {
  str_app_all_site+=crt_str_of_res_data('smtp',dec_data[i]['smtp_name'],dec_data[i]['smtp_id'],0);
};


$("#all-smtp-server").html(str_app_all_site);



set_all_sender_data();

        });



}


function set_all_sender_data(){




$.ajax({
                url : "https://account.sycista.com/account/ajaxfile-pages/get_all_sender.php",
                type: "GET"
                
        }).done(function(response){ 
str_app_all_site="";

dec_data=JSON.parse(response);


		$("#sender_cnt_dt").html(dec_data.length);

for (var i = 0; i < dec_data.length; i++) {
  str_app_all_site+=crt_str_of_res_data('sender',dec_data[i]['email'],dec_data[i]['sender_id'],0);
};


$("#all-sender-id").html(str_app_all_site);




        });




}



function crt_str_of_res_data(type,sw_str,id,flg_val){

  if(type=="sites"){

    if(flg_val==1){

      ico_str='<i class="fad fa-browser ico-of-sede-sub-dp"></i>';


    }else{

    ico_str='<i class="fal fa-browser ico-of-sede-sub-dp"></i>';

  }
  }else if(type=='smtp'){

    ico_str='<i class="fal fa-server ico-of-sede-sub-dp"></i>';
  }else if(type=='sender'){

    ico_str='<i class="fal fa-user ico-of-sede-sub-dp"></i>';
  }


str_ret='<a class="dropdown-item lnk_clk" data-href="sites/ajaxfile/sess_site_crt.php?site_id='+id+'&site_name='+sw_str+'" trg-type="'+type+'" href="#" id="'+id+'">'+ico_str+sw_str+'</a>';

return str_ret;

}

<?php

require("../../confige/user_database.php");
require("../../confige/account_database.php");


function get_random_id($digits){


return rand(pow(10, $digits-1), pow(10, $digits)-1);

}


function rendom_str_for_uniq($x){

return substr(str_shuffle("0123456789abcdefghijklmnopqrstvwxyzABCDEFGHIJKLMNOPQRSTVWXYZ"), 0, $x);

}

$req_data=$_POST;

$email=$req_data['email'];
$pass=$req_data['password'];

$id=get_random_id(9);

$var_link=rendom_str_for_uniq(20);

$curr_date=date("Y-m-d");

$isrt_sign_up="insert into userinfo (id,email,pass,varflag,extra,date) value ('$id','$email','$pass','0','$var_link','$curr_date')";


if ($conn_usr->query($isrt_sign_up) === TRUE) {




$up_query_account="insert into profile_data (id) value ('$id')";




if ($conn_account->query($up_query_account) === TRUE) {
  echo 1;
} else {
  echo 0;
}





} else {
  echo 0;
}




?>




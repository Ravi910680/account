<?php
session_start();


$_SESSION['site_id']=$_GET['site_id'];

$_SESSION['site_name']=$_GET['site_name'];

header("Location: ../site_data/");
?>

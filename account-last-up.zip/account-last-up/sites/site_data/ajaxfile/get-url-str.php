<?php


error_reporting(E_ALL ^ E_WARNING); 




function shorten_string($string, $wordsreturned)
{
    $retval = $string;  //  Just in case of a problem
    $array = explode(" ", $string);
    /*  Already short enough, return the whole thing*/
    if (count($array)<=$wordsreturned)
    {
        $retval = $string;
    }
    /*  Need to chop of some words*/
    else
    {
        array_splice($array, $wordsreturned);
        $retval = implode(" ", $array)." ...";
    }
    return $retval;
}




function httpGet($url)
{
    $ch = curl_init();  

    $url = str_replace(" ", '%20', $url);
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
    
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}




function get_title_of_page($doc,$tag,$type=0){




$title = $doc->getElementsByTagName($tag);



if($type<5){


if($title->length>0){




foreach($title as $con) {


return $con->nodeValue;

    

}





}else{

    


return get_title_of_page($doc,"h".(string)($type+1),$type+1);

}

}


}



$req_data=$_GET;



$page=file_get_contents($req_data['url']);



$doc = new DOMDocument();
$doc->loadHTML($page);
$divs = $doc->getElementsByTagName('p');



$flg_res=0;


$txt_fld="";

foreach($divs as $div) {
   

   if(substr_count($txt_fld," ")>=50){


break;
   }else{




   	$txt_fld.=$div->nodeValue;


   }
   

    
}

$img_url="";

$img = $doc->getElementsByTagName('img');



foreach($img as $con) {



	list($width, $height, $type, $attr) = getimagesize($con->getAttribute('src'));

	if($width>400){

$img_url=$con->getAttribute('src');
break;

	}

}

$title=get_title_of_page($doc,'title');
$title=shorten_string($title,5);


$txt= shorten_string($txt_fld,20); 
$url=$req_data['url'];



$str_url="http://localhost/html/dash/main/template/edit/temp-blog/main-repeat/test-blog-repeat.php?img=".$img_url."&text=".$txt."&url=".$url."&title=".$title;


$str_of_repeat= httpGet($str_url);



echo $str_of_repeat;








?>
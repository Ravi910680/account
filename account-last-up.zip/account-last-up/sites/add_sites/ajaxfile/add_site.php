<?php
session_start();
require("../../../confige/url_database.php");
require("../../../confige/url_crawl_data.php");
function get_random_id($digits){


return rand(pow(10, $digits-1), pow(10, $digits)-1);

}

$id=$_SESSION['id'];



$req_data=$_POST;


$url=$req_data['req_url'];

$date= date('Y-m-d H:i:s');

$url_id=get_random_id(9);

$isrt_url_data="insert into url_connect (id,url,date,status,url_id) value ('$id','$url','$date','0','$url_id')";



if ($conn_url->query($isrt_url_data) === TRUE) {
      

	$crt_tble_query="CREATE TABLE `".$url_id."` ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, url varchar(300),keyword varchar(255),date date  )";

	if($conn_crw->query($crt_tble_query) === TRUE){

	echo 1;
	}else{

echo $conn_crw->error;
	}


} else {
  echo $conn_url->error;
}




?>

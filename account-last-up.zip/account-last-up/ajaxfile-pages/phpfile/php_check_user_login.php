<?php
session_start();

require("../../confige/user_database.php");


$res_arr=array();

$id=$_SESSION['id'];

$sel_query_usr="select * from userinfo where id='$id'";

$result = $conn_usr->query($sel_query_usr);


if ($result->num_rows > 0) {


$row = $result->fetch_assoc();

$res_arr['id']=$row['id'];

$res_arr['flg']="auth";

$res_arr['email']=$row['email'];
   


}else{


$res_arr['flg']="not-auth";

}

print_r(json_encode($res_arr));


?>

<?php
session_start();

require("../../../confige/sender_database.php");

function get_random_id($digits){


return rand(pow(10, $digits-1), pow(10, $digits)-1);

}

$id=$_SESSION['id'];
$req_data=$_POST;


$name=$req_data['name'];
$email=$req_data['email'];


$date= date('Y-m-d H:i:s');

$sender_id=$id.get_random_id(3);



$isrt_sender_data="insert into sender_data (id,sender_id,name,email,date) value ('$id','$sender_id','$name','$email','$date')";




if ($conn_sender->query($isrt_sender_data) === TRUE) {
  echo 1;
} else {
  echo 0;
}


?>
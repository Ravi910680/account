

<?php

function tag_count_init_fun($id){
echo $id;






$servername = "database.cvzwmawluvxi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";

$db5="managetag";

$mngtag = mysqli_connect($servername, $username, $password,$db5);



$i=0;
$tbl_name="tag".$id;

$arr_of_tag=array("newsletter","office","employe","marketing","new","exit");

$h=11;
foreach ($arr_of_tag as $value) {
  # code...


$sql_tag_in = "INSERT INTO `".$tbl_name."` (id,tag) VALUES ('$h','$value')";
if ($mngtag->query($sql_tag_in) === TRUE) {
  $i+=1;
}else{

echo $mngtag->error;

}

$h+=1;


}

return $i;
}




?>






<?php


$servername = "database.cvzwmawluvxi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="signup";

$conn = mysqli_connect($servername, $username, $password,$db);



$db5="managetag";

$mngtag = mysqli_connect($servername, $username, $password,$db5);











$servername = "studio.cnenb266gjbe.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";


$dbname = "imagedir";

$imagedir = mysqli_connect($servername, $username, $password,$dbname);
$dbname = "imagesave";




$imagesave = mysqli_connect($servername, $username, $password,$dbname);





require("./tag_count_init.php");











function crt_tbl_of_img_data($conn,$tbl_name){




$imagetbl = "CREATE TABLE `".$tbl_name."`(
      image VARCHAR(50) PRIMARY KEY NOT NULL,
        width VARCHAR(30),
        height VARCHAR(30),
  size VARCHAR(255),
image_name VARCHAR(255),
date_img DATETIME
    )";


if(($conn->query($imagetbl)===TRUE)){

return TRUE;

}else{

return false;

}




}



function str_img_dir_name($conn,$dir_name){



$insertdatasql = "INSERT INTO `imagedirname` VALUES ('$dir_name','$id','$date','0','0','2')";



if($conn->query($insertdatasql) === TRUE){

return TRUE;


}else{

  return false;
}


}






// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$vary=$_GET["key"];
$id=$_GET["id"];







$sql="SELECT * FROM userinfo WHERE id='$id' and extra='$vary'";

$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count==1){
   $date= date("Y-m-d");
$tbl_name_def=$id."^".base64_encode("undefine");




echo crt_tbl_of_img_data($imagesave,$tbl_name_def);


str_img_dir_name($imagedir,$tbl_name_def);

$tbl_name_def=$id."^".base64_encode("custumized");



echo crt_tbl_of_img_data($imagesave,$tbl_name_def);


str_img_dir_name($imagedir,$tbl_name_def);

$tbl_name_def=$id."^".base64_encode("soc_code");



crt_tbl_of_img_data($imagesave,$tbl_name_def);


str_img_dir_name($imagedir,$tbl_name_def);

$tbl_name_def=$id."^".base64_encode("cloud_code");



crt_tbl_of_img_data($imagesave,$tbl_name_def);


str_img_dir_name($imagedir,$tbl_name_def);







$tag_tbl = "CREATE TABLE `tag".$id."`(
      tag  VARCHAR(50) NOT NULL,date DATE,
      id INT(3) AUTO_INCREMENT PRIMARY KEY NOT NULL,
UNIQUE (tag)
    )";










if($mngtag->query($tag_tbl)==TRUE){

$tag_count_init=tag_count_init_fun($id);

if($tag_count_init==6){

$sql = "UPDATE userinfo SET varflag=1 WHERE id='$id'";

if($conn->query($sql) === TRUE){


}else{

  echo 8;
  
}






}








}else{
echo("Error description: " . $mngtag-> error);
}
}
?>

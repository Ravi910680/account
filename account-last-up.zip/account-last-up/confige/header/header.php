<?php

$mail=$_SESSION['email'];
$id=$_SESSION['id'];


?>

<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <style>




body{
  font-family: 'IBM Plex Sans', sans-serif;
letter-spacing:0.2px;
}




  .dropdown-menu{
    border-radius:0px !important;
    box-shadow:none !important;
    
    border:1px solid #dedddc !important;
    
}

.nav-link:hover{
    cursor:pointer;
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.main-content {
    position: relative;
    top: 8vh;
}

a{
    font-weight:600;
}
  .navbar-light .navbar-brand {
    color: white;

  }


.dropdown-menu .dropdown-item>i, .dropdown-menu .dropdown-item>svg {
    margin-right: 1rem;

}

  .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
    color: white;

  }
  .navbar {
    background: #4a154b;
}



.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size:0.9rem !important;
    font-weight: 600;

padding: 20px 10px !important;
}

.dropdown-menu.show {
    border-radius: 10px !important;

}



.navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
    color: white;

}


.navbar-light .navbar-nav .show>.nav-link, .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .nav-link.active {
    color: white;
}
.modal{

background: #00000070;

}

.c-slacklogo{display:flex;align-items:center;padding: 0px 20px;}
.c-slacklogo a{line-height:inherit;display:inline-block;font-size:0;padding:0;border:none}
.c-slacklogo img{vertical-align:top}
.c-slacklogo--white{display:none}
.c-slacklogo--color{display:inline-block}
@media screen and (min-width:67.8125rem){.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--white{display:inline-block}
.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--color{display:none}
}
.c-slacklogo--pillow{width:auto;fill:#fff}
.c-slacklogo.v-frontiers{width:205px;z-index:1}
.c-nav__mobile .c-slacklogo.v-frontiers svg{margin-left:1rem}

.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
    color: white;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size: 2vh;
    font-weight: 600;
    padding: 2.5vh 10px !important;
  }


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;

    }

    button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
  }

  .dropdown-caret {
    display: inline-block;
    width: 0;
    height: 0;
    vertical-align: middle;
    content: "";
    border-top-style: solid;
    border-top-width: 4px;
    border-right: 4px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 4px solid transparent;

  }

  #main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}
  .dropdown-item:hover{

cursor: pointer;
  }
  </style>
  <nav class="navbar navbar-expand-lg navbar-light" style="height:8vh;position:fixed;width:100%;z-index:100000000;border-bottom:1px solid #dedddc;padding:0px;">
  <div class="c-slacklogo">



<svg width="4vh" height="4vh" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="
    color: white;
"><path d="M16.6818 15.7529L18.8116 17.8827C20.1752 16.3052 21 14.249 21 12.0001C21 9.78747 20.2016 7.76133 18.8771 6.19409L16.7444 8.32671C17.5315 9.34177 18 10.6162 18 12.0001C18 13.4203 17.5066 14.7253 16.6818 15.7529Z" fill="currentColor" fill-opacity="0.5"></path><path d="M15.6734 16.7445C14.6583 17.5315 13.3839 18 12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C13.4202 6 14.7252 6.49344 15.7528 7.31823L17.8826 5.18843C16.3051 3.82482 14.2489 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21C14.2126 21 16.2387 20.2016 17.806 18.8771L15.6734 16.7445Z" fill="currentColor"></path></svg>
    
</div>
  
  <div class=" navbar-collapse">
    <ul class="navbar-nav">
      <li class="nav-item">
      <div class="dropdown">
        <a class="nav-link"  data-toggle="dropdown" >Campign <span class="dropdown-caret"></span></a>
        <div class="dropdown-menu">





<button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 7H9V9H7V7Z" fill="currentColor" /><path d="M11 7H13V9H11V7Z" fill="currentColor" /><path d="M17 7H15V9H17V7Z" fill="currentColor" /><path d="M7 11H9V13H7V11Z" fill="currentColor" /><path d="M13 11H11V13H13V11Z" fill="currentColor" /><path d="M15 11H17V13H15V11Z" fill="currentColor" /><path d="M9 15H7V17H9V15Z" fill="currentColor" /><path d="M11 15H13V17H11V15Z" fill="currentColor" /><path d="M17 15H15V17H17V15Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      All campign </span></button>




         <button class="dropdown-item comm_up_btn"  >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 4H18V6H20V8H18V10H16V8H14V6H16V4Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M12 12V6H4V20H18V12H12ZM6 8H10V12H6V8ZM10 14V18H6V14H10ZM16 14V18H12V14H16Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Create Campign </span></button>



      





<button class="dropdown-item comm_up_btn"  >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M22.775 8C22.9242 8.65461 23 9.32542 23 10H14V1C14.6746 1 15.3454 1.07584 16 1.22504C16.4923 1.33724 16.9754 1.49094 17.4442 1.68508C18.5361 2.13738 19.5282 2.80031 20.364 3.63604C21.1997 4.47177 21.8626 5.46392 22.3149 6.55585C22.5091 7.02455 22.6628 7.5077 22.775 8ZM20.7082 8C20.6397 7.77018 20.5593 7.54361 20.4672 7.32122C20.1154 6.47194 19.5998 5.70026 18.9497 5.05025C18.2997 4.40024 17.5281 3.88463 16.6788 3.53284C16.4564 3.44073 16.2298 3.36031 16 3.2918V8H20.7082Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M1 14C1 9.02944 5.02944 5 10 5C10.6746 5 11.3454 5.07584 12 5.22504V12H18.775C18.9242 12.6546 19 13.3254 19 14C19 18.9706 14.9706 23 10 23C5.02944 23 1 18.9706 1 14ZM16.8035 14H10V7.19648C6.24252 7.19648 3.19648 10.2425 3.19648 14C3.19648 17.7575 6.24252 20.8035 10 20.8035C13.7575 20.8035 16.8035 17.7575 16.8035 14Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Campign Analysis </span></button>




    </div>
  </div>
      </li>
      <li class="nav-item">
      <div class="dropdown">
        <a class="nav-link"  data-toggle="dropdown" >Studio <span class="dropdown-caret"></span></a>
	<div class="dropdown-menu">



<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv='1' data-path-ses="studio/"  data-target-link='https://studio.sycista.com/studio/'    >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16.6818 15.7529L18.8116 17.8827C20.1752 16.3052 21 14.249 21 12.0001C21 9.78747 20.2016 7.76133 18.8771 6.19409L16.7444 8.32671C17.5315 9.34177 18 10.6162 18 12.0001C18 13.4203 17.5066 14.7253 16.6818 15.7529Z" fill="currentColor" fill-opacity="0.5" /><path d="M15.6734 16.7445C14.6583 17.5315 13.3839 18 12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C13.4202 6 14.7252 6.49344 15.7528 7.31823L17.8826 5.18843C16.3051 3.82482 14.2489 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21C14.2126 21 16.2387 20.2016 17.806 18.8771L15.6734 16.7445Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Browse Studio </span></button>




         <button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv='0' data-target-link='https://studio.sycista.com/studio/#mdl@crt-new-dir-mdl'    >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 14.5V16.5H13V14.5H15V12.5H13V10.5H11V12.5H9V14.5H11Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M4 1.5C2.89543 1.5 2 2.39543 2 3.5V4.5C2 4.55666 2.00236 4.61278 2.00698 4.66825C0.838141 5.07811 0 6.19118 0 7.5V19.5C0 21.1569 1.34315 22.5 3 22.5H21C22.6569 22.5 24 21.1569 24 19.5V7.5C24 5.84315 22.6569 4.5 21 4.5H11.874C11.4299 2.77477 9.86384 1.5 8 1.5H4ZM9.73244 4.5C9.38663 3.9022 8.74028 3.5 8 3.5H4V4.5H9.73244ZM3 6.5C2.44772 6.5 2 6.94772 2 7.5V19.5C2 20.0523 2.44772 20.5 3 20.5H21C21.5523 20.5 22 20.0523 22 19.5V7.5C22 6.94772 21.5523 6.5 21 6.5H3Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Create Directory </span></button>



      <button class="dropdown-item comm_up_btn com-for-lnk" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M14.364 13.1214C15.2876 14.045 15.4831 15.4211 14.9504 16.5362L16.4853 18.0711C16.8758 18.4616 16.8758 19.0948 16.4853 19.4853C16.0948 19.8758 15.4616 19.8758 15.0711 19.4853L13.5361 17.9504C12.421 18.4831 11.045 18.2876 10.1213 17.364C8.94975 16.1924 8.94975 14.2929 10.1213 13.1214C11.2929 11.9498 13.1924 11.9498 14.364 13.1214ZM12.9497 15.9498C13.3403 15.5593 13.3403 14.9261 12.9497 14.5356C12.5592 14.145 11.9261 14.145 11.5355 14.5356C11.145 14.9261 11.145 15.5593 11.5355 15.9498C11.9261 16.3403 12.5592 16.3403 12.9497 15.9498Z" fill="currentColor" /><path d="M8 5H16V7H8V5Z" fill="currentColor" /><path d="M16 9H8V11H16V9Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M4 4C4 2.34315 5.34315 1 7 1H17C18.6569 1 20 2.34315 20 4V20C20 21.6569 18.6569 23 17 23H7C5.34315 23 4 21.6569 4 20V4ZM7 3H17C17.5523 3 18 3.44772 18 4V20C18 20.5523 17.5523 21 17 21H7C6.44772 21 6 20.5523 6 20V4C6 3.44772 6.44771 3 7 3Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Search Image </span></button>



<div class="dropdown-divider"></div>

<button class="dropdown-item comm_up_btn com-for-lnk" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 11C13.1046 11 14 10.1046 14 9C14 7.89543 13.1046 7 12 7C10.8954 7 10 7.89543 10 9C10 10.1046 10.8954 11 12 11Z" fill="currentColor" /><path d="M11 13C11 14.1046 10.1046 15 9 15C7.89543 15 7 14.1046 7 13C7 11.8954 7.89543 11 9 11C10.1046 11 11 11.8954 11 13Z" fill="currentColor" /><path d="M15 15C16.1046 15 17 14.1046 17 13C17 11.8954 16.1046 11 15 11C13.8954 11 13 11.8954 13 13C13 14.1046 13.8954 15 15 15Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 4C3 2.34315 4.34315 1 6 1H18C19.6569 1 21 2.34315 21 4V20C21 21.6569 19.6569 23 18 23H6C4.34315 23 3 21.6569 3 20V4ZM6 3H18C18.5523 3 19 3.44772 19 4V20C19 20.5523 18.5523 21 18 21H6C5.44772 21 5 20.5523 5 20V4C5 3.44772 5.44772 3 6 3Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Used It  </span></button>



    </div>
  </div>
      </li>
      




<li class="nav-item">
      <div class="dropdown">
        <a class="nav-link"  data-toggle="dropdown" >Template <span class="dropdown-caret"></span></a>
        <div class="dropdown-menu">
         <button class="dropdown-item comm_up_btn"  >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 7H9V9H7V7Z" fill="currentColor" /><path d="M11 7H13V9H11V7Z" fill="currentColor" /><path d="M17 7H15V9H17V7Z" fill="currentColor" /><path d="M7 11H9V13H7V11Z" fill="currentColor" /><path d="M13 11H11V13H13V11Z" fill="currentColor" /><path d="M15 11H17V13H15V11Z" fill="currentColor" /><path d="M9 15H7V17H9V15Z" fill="currentColor" /><path d="M11 15H13V17H11V15Z" fill="currentColor" /><path d="M17 15H15V17H17V15Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      All Template </span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3 3V9H21V3H3ZM19 5H5V7H19V5Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 11V21H11V11H3ZM9 13H5V19H9V13Z" fill="currentColor" /><path d="M21 11H13V13H21V11Z" fill="currentColor" /><path d="M13 15H21V17H13V15Z" fill="currentColor" /><path d="M21 19H13V21H21V19Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Create Template </span></button>


      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M13 12.8293C14.1652 12.4175 15 11.3062 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.3062 9.83481 12.4175 11 12.8293V16C11 16.5523 11.4477 17 12 17C12.5523 17 13 16.5523 13 16V12.8293ZM11 10C11 10.5523 11.4477 11 12 11C12.5523 11 13 10.5523 13 10C13 9.44772 12.5523 9 12 9C11.4477 9 11 9.44772 11 10Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      API Template </span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 11C13.1046 11 14 10.1046 14 9C14 7.89543 13.1046 7 12 7C10.8954 7 10 7.89543 10 9C10 10.1046 10.8954 11 12 11Z" fill="currentColor" /><path d="M11 13C11 14.1046 10.1046 15 9 15C7.89543 15 7 14.1046 7 13C7 11.8954 7.89543 11 9 11C10.1046 11 11 11.8954 11 13Z" fill="currentColor" /><path d="M15 15C16.1046 15 17 14.1046 17 13C17 11.8954 16.1046 11 15 11C13.8954 11 13 11.8954 13 13C13 14.1046 13.8954 15 15 15Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 4C3 2.34315 4.34315 1 6 1H18C19.6569 1 21 2.34315 21 4V20C21 21.6569 19.6569 23 18 23H6C4.34315 23 3 21.6569 3 20V4ZM6 3H18C18.5523 3 19 3.44772 19 4V20C19 20.5523 18.5523 21 18 21H6C5.44772 21 5 20.5523 5 20V4C5 3.44772 5.44772 3 6 3Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Feature To use </span></button>
    </div>
  </div>
      </li>



      



<li class="nav-item">
      
        <a class="nav-link"  data-toggle="dropdown" >Social </a>
        
      </li>




<li class="nav-item">
      
        <a class="nav-link"  data-toggle="dropdown" >List </a>
        
      </li>


      
      
    </ul>

    
  </div>
  <ul class="navbar-nav align-items-center d-none d-md-flex">


    <li class="nav-item dropdown" style="
    color: white;
">
            <svg class="octicon octicon-bell" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" style="fill:white;
"><path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path></svg>
          </li>
          <li class="nav-item dropdown">
            <a class=" pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                
                <div class="media-body ml-2 d-none d-lg-block" style="">
                  

<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin:2vh;color:white;"><path d="M7 7H9V9H7V7Z" fill="currentColor" /><path d="M11 7H13V9H11V7Z" fill="currentColor" /><path d="M17 7H15V9H17V7Z" fill="currentColor" /><path d="M7 11H9V13H7V11Z" fill="currentColor" /><path d="M13 11H11V13H13V11Z" fill="currentColor" /><path d="M15 11H17V13H15V11Z" fill="currentColor" /><path d="M9 15H7V17H9V15Z" fill="currentColor" /><path d="M11 15H13V17H11V15Z" fill="currentColor" /><path d="M17 15H15V17H17V15Z" fill="currentColor" /></svg>


                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
              <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0"><?php echo $mail;?></h6>
              </div>
              


<button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Connected App </span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Sender Profile</span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor" /><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor" /><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      SMTP Server </span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Integration </span></button>



      <button class="dropdown-item comm_up_btn" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor" /><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor" /><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor" /><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      API</span></button>







              <div class="dropdown-divider"></div>


 <button class="dropdown-item comm_up_btn" data-for-serv='1' data-target-link='http://account.sycista.com/logout/' >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Plan</span></button>

               <button class="dropdown-item comm_up_btn com"  data-for-serv='1' data-target-link='http://account.sycista.com/logout/' >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor" /><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor" /></svg>
<span class="padding-left:10px;">
      Log Out</span></button>


            </div>
          </li>
        </ul>
</nav>

<script type="text/javascript">


id='<?php echo $id;?>';
email='<?php echo $mail;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');


url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})





</script>



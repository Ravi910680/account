<?php
$servername = "database-1.c1xleyzjkk8s.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="signup";

$conn = mysqli_connect($servername, $username, $password,$db);
if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());}else{

}
// Check connection
?>


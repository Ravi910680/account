<?php

session_start();
require("../../../confige/pln_db.php");

$id=$_SESSION['id'];

function change_activated_pln($conn,$past_id,$now_id){

$id=$GLOBALS['id'];

$up_query="update used_credit set flg_act='0' where pln_id='".$past_id."' and id='".$id."'";

if ($conn->query($up_query) === TRUE) {
  

  $up_query="update used_credit set flg_act='1' where pln_id='".$now_id."' and id='".$id."'";

if ($conn->query($up_query) === TRUE) {
  echo 1;
} else {
  echo 0;
}


} else {
  echo 0;
}



}










$past_data=$_POST['past_act'];
$now_data=$_POST['now_act'];

change_activated_pln($conn_pln,$past_data,$now_data);

?>
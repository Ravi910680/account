<?php



function active_pln_id($conn,$id){


$sel_query="select * from used_credit where id='".$id."' and flg_act='1'";

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    return $row;
  }
} else {
 return 0;
}

}

function get_pln_full_credit($conn,$id,$pln_id){



$sel_query="select * from pln_data where id='".$id."' and pln_id='".$pln_id."'";

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    return $row;
  }
} 
}




?>
<?php

session_start();
require("../../../confige/pln_db.php");


function active_pln_id($conn,$id,$pln_id){


$sel_query="select * from used_credit where id='".$id."' and pln_id='".$pln_id."'";

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    return $row['flg_act'];
  }
} else {
 return 0;
}

}

function get_pln_full_credit($conn,$id){



$sel_query="select * from pln_data where id='".$id."'";

$result = $conn->query($sel_query);
$ret_arr=array("all_pln"=>array());

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    
$act_data=active_pln_id($conn,$id,$row['pln_id']);

if($act_data){
$ret_arr['active_account']=$row['pln_id'];

}
    $row['flg_act']=$act_data;

    array_push($ret_arr["all_pln"],$row);
  }
}else{

return 0;

}

return $ret_arr; 
}

$id=$_SESSION['id'];

$result=get_pln_full_credit($conn_pln,$id);

if($result==0){

echo 0;

}else{

print_r(json_encode($result));

}



?>
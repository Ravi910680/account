<?php
session_start();
require("../../../confige/pln_db.php");
require("./get_active_pln_id.php");


$id=$_SESSION['id'];

$act_pln_data=active_pln_id($conn_pln,$id);


if($act_pln_data==0){



echo 0;



}else{

$full_pln_data=get_pln_full_credit($conn_pln,$id,$act_pln_data['pln_id']);

$i=0;

$ret_arr_data=array();

$cnt=count($act_pln_data);
foreach ($act_pln_data as $key => $value) {

	$i+=1;
	# code...
	if($i>2 && $i<$cnt){
$ret_arr_data[$key]['usd']=$act_pln_data[$key];
$ret_arr_data[$key]['full']=$full_pln_data[$key];
		
	}
}

print_r(json_encode($ret_arr_data));


}
?>